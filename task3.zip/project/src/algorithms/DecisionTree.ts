import { DecisionNode, ProcessedData, ModelMetrics } from '../types';

export class DecisionTreeClassifier {
  private root: DecisionNode | null = null;
  private maxDepth: number;
  private minSamplesSplit: number;
  private minSamplesLeaf: number;

  constructor(
    maxDepth: number = 10,
    minSamplesSplit: number = 2,
    minSamplesLeaf: number = 1
  ) {
    this.maxDepth = maxDepth;
    this.minSamplesSplit = minSamplesSplit;
    this.minSamplesLeaf = minSamplesLeaf;
  }

  public train(data: ProcessedData[]): void {
    this.root = this.buildTree(data, 0);
  }

  private buildTree(data: ProcessedData[], depth: number): DecisionNode {
    const targets = data.map(d => d.target);
    const uniqueTargets = [...new Set(targets)];
    const samples = data.length;

    // Check stopping criteria
    if (
      uniqueTargets.length === 1 ||
      depth >= this.maxDepth ||
      samples < this.minSamplesSplit
    ) {
      return this.createLeafNode(targets, samples);
    }

    // Find best split
    const bestSplit = this.findBestSplit(data);
    if (!bestSplit) {
      return this.createLeafNode(targets, samples);
    }

    const { feature, threshold, leftData, rightData } = bestSplit;

    // Check minimum samples in leaf
    if (leftData.length < this.minSamplesLeaf || rightData.length < this.minSamplesLeaf) {
      return this.createLeafNode(targets, samples);
    }

    const leftChild = this.buildTree(leftData, depth + 1);
    const rightChild = this.buildTree(rightData, depth + 1);

    return {
      feature,
      threshold,
      left: leftChild,
      right: rightChild,
      samples,
      gini: this.calculateGini(targets),
      isLeaf: false
    };
  }

  private createLeafNode(targets: number[], samples: number): DecisionNode {
    const prediction = this.getMajorityClass(targets);
    return {
      prediction,
      samples,
      gini: this.calculateGini(targets),
      isLeaf: true
    };
  }

  private findBestSplit(data: ProcessedData[]) {
    let bestGini = Infinity;
    let bestFeature: number | null = null;
    let bestThreshold: number | null = null;
    let bestLeftData: ProcessedData[] = [];
    let bestRightData: ProcessedData[] = [];

    const numFeatures = data[0].features.length;

    for (let feature = 0; feature < numFeatures; feature++) {
      const values = data.map(d => d.features[feature]);
      const uniqueValues = [...new Set(values)].sort((a, b) => a - b);

      for (let i = 0; i < uniqueValues.length - 1; i++) {
        const threshold = (uniqueValues[i] + uniqueValues[i + 1]) / 2;
        const { leftData, rightData } = this.splitData(data, feature, threshold);

        if (leftData.length === 0 || rightData.length === 0) continue;

        const gini = this.calculateWeightedGini(leftData, rightData);

        if (gini < bestGini) {
          bestGini = gini;
          bestFeature = feature;
          bestThreshold = threshold;
          bestLeftData = leftData;
          bestRightData = rightData;
        }
      }
    }

    if (bestFeature === null) return null;

    return {
      feature: bestFeature,
      threshold: bestThreshold!,
      leftData: bestLeftData,
      rightData: bestRightData
    };
  }

  private splitData(data: ProcessedData[], feature: number, threshold: number) {
    const leftData = data.filter(d => d.features[feature] <= threshold);
    const rightData = data.filter(d => d.features[feature] > threshold);
    return { leftData, rightData };
  }

  private calculateGini(targets: number[]): number {
    if (targets.length === 0) return 0;

    const counts = targets.reduce((acc, target) => {
      acc[target] = (acc[target] || 0) + 1;
      return acc;
    }, {} as Record<number, number>);

    let gini = 1;
    for (const count of Object.values(counts)) {
      const probability = count / targets.length;
      gini -= probability * probability;
    }

    return gini;
  }

  private calculateWeightedGini(leftData: ProcessedData[], rightData: ProcessedData[]): number {
    const totalSamples = leftData.length + rightData.length;
    const leftWeight = leftData.length / totalSamples;
    const rightWeight = rightData.length / totalSamples;

    const leftTargets = leftData.map(d => d.target);
    const rightTargets = rightData.map(d => d.target);

    return leftWeight * this.calculateGini(leftTargets) + rightWeight * this.calculateGini(rightTargets);
  }

  private getMajorityClass(targets: number[]): number {
    const counts = targets.reduce((acc, target) => {
      acc[target] = (acc[target] || 0) + 1;
      return acc;
    }, {} as Record<number, number>);

    return parseInt(Object.keys(counts).reduce((a, b) => counts[a] > counts[b] ? a : b));
  }

  public predict(features: number[]): number {
    if (!this.root) throw new Error('Model not trained');
    return this.predictSingle(this.root, features);
  }

  private predictSingle(node: DecisionNode, features: number[]): number {
    if (node.isLeaf) {
      return node.prediction!;
    }

    if (features[node.feature!] <= node.threshold!) {
      return this.predictSingle(node.left!, features);
    } else {
      return this.predictSingle(node.right!, features);
    }
  }

  public predictProbability(features: number[]): number {
    if (!this.root) throw new Error('Model not trained');
    const leafNode = this.findLeaf(this.root, features);
    // Simple probability based on leaf purity
    return leafNode.gini! < 0.5 ? 0.8 : 0.6;
  }

  private findLeaf(node: DecisionNode, features: number[]): DecisionNode {
    if (node.isLeaf) {
      return node;
    }

    if (features[node.feature!] <= node.threshold!) {
      return this.findLeaf(node.left!, features);
    } else {
      return this.findLeaf(node.right!, features);
    }
  }

  public evaluate(testData: ProcessedData[]): ModelMetrics {
    const predictions = testData.map(d => this.predict(d.features));
    const actuals = testData.map(d => d.target);

    const confusionMatrix = this.buildConfusionMatrix(actuals, predictions);
    const accuracy = this.calculateAccuracy(actuals, predictions);
    const precision = this.calculatePrecision(confusionMatrix);
    const recall = this.calculateRecall(confusionMatrix);
    const f1Score = (2 * precision * recall) / (precision + recall);

    return {
      accuracy,
      precision,
      recall,
      f1Score,
      confusionMatrix
    };
  }

  private buildConfusionMatrix(actuals: number[], predictions: number[]): number[][] {
    const matrix = [[0, 0], [0, 0]];
    
    for (let i = 0; i < actuals.length; i++) {
      matrix[actuals[i]][predictions[i]]++;
    }

    return matrix;
  }

  private calculateAccuracy(actuals: number[], predictions: number[]): number {
    const correct = actuals.filter((actual, i) => actual === predictions[i]).length;
    return correct / actuals.length;
  }

  private calculatePrecision(confusionMatrix: number[][]): number {
    const truePositives = confusionMatrix[1][1];
    const falsePositives = confusionMatrix[0][1];
    return truePositives / (truePositives + falsePositives) || 0;
  }

  private calculateRecall(confusionMatrix: number[][]): number {
    const truePositives = confusionMatrix[1][1];
    const falseNegatives = confusionMatrix[1][0];
    return truePositives / (truePositives + falseNegatives) || 0;
  }

  public getTree(): DecisionNode | null {
    return this.root;
  }
}