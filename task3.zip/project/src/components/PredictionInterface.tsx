import React, { useState } from 'react';
import { DecisionTreeClassifier } from '../algorithms/DecisionTree';
import { DataPreprocessor } from '../utils/dataPreprocessing';
import { CustomerData, PredictionResult } from '../types';
import { 
  jobCategories, maritalCategories, educationCategories, 
  monthCategories, dayCategories, contactCategories, 
  poutcomeCategories, binaryCategories 
} from '../data/sampleData';
import { Calculator, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';

interface PredictionInterfaceProps {
  model: DecisionTreeClassifier | null;
}

export const PredictionInterface: React.FC<PredictionInterfaceProps> = ({ model }) => {
  const [customerData, setCustomerData] = useState<Partial<CustomerData>>({
    age: 35,
    job: 'admin.',
    marital: 'married',
    education: 'university.degree',
    default: 'no',
    housing: 'yes',
    loan: 'no',
    contact: 'cellular',
    month: 'may',
    day_of_week: 'mon',
    duration: 300,
    campaign: 1,
    pdays: 999,
    previous: 0,
    poutcome: 'nonexistent',
    emp_var_rate: 1.1,
    cons_price_idx: 93.994,
    cons_conf_idx: -36.4,
    euribor3m: 4.857,
    nr_employed: 5191.0
  });

  const [prediction, setPrediction] = useState<PredictionResult | null>(null);

  const handleInputChange = (field: keyof CustomerData, value: string | number) => {
    setCustomerData(prev => ({ ...prev, [field]: value }));
  };

  const makePrediction = () => {
    if (!model) return;

    try {
      const preprocessor = new DataPreprocessor();
      const processedData = preprocessor.preprocessSingle({
        ...customerData,
        y: 'no' // dummy value
      } as CustomerData);

      const predictionValue = model.predict(processedData.features);
      const probability = model.predictProbability(processedData.features);

      const result: PredictionResult = {
        prediction: predictionValue === 1 ? 'Will Purchase' : 'Will Not Purchase',
        probability: predictionValue === 1 ? probability : 1 - probability,
        confidence: probability > 0.7 ? 1 : probability > 0.6 ? 0.8 : 0.6
      };

      setPrediction(result);
    } catch (error) {
      console.error('Prediction failed:', error);
    }
  };

  if (!model) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center mb-4">
          <Calculator className="w-6 h-6 text-gray-400 mr-3" />
          <h3 className="text-xl font-bold text-gray-400">Customer Prediction</h3>
        </div>
        <div className="text-center py-8">
          <AlertTriangle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">Please train a model first to make predictions</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center mb-6">
        <Calculator className="w-6 h-6 text-blue-600 mr-3" />
        <h3 className="text-xl font-bold text-gray-800">Customer Prediction</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {/* Demographic Inputs */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Age</label>
          <input
            type="number"
            value={customerData.age || ''}
            onChange={(e) => handleInputChange('age', parseInt(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            min="18"
            max="95"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Job</label>
          <select
            value={customerData.job || ''}
            onChange={(e) => handleInputChange('job', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {jobCategories.map(job => (
              <option key={job} value={job}>{job}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Marital Status</label>
          <select
            value={customerData.marital || ''}
            onChange={(e) => handleInputChange('marital', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {maritalCategories.map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Education</label>
          <select
            value={customerData.education || ''}
            onChange={(e) => handleInputChange('education', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {educationCategories.map(edu => (
              <option key={edu} value={edu}>{edu}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Housing Loan</label>
          <select
            value={customerData.housing || ''}
            onChange={(e) => handleInputChange('housing', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {binaryCategories.map(option => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Personal Loan</label>
          <select
            value={customerData.loan || ''}
            onChange={(e) => handleInputChange('loan', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {binaryCategories.map(option => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Contact Type</label>
          <select
            value={customerData.contact || ''}
            onChange={(e) => handleInputChange('contact', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {contactCategories.map(contact => (
              <option key={contact} value={contact}>{contact}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Call Duration (seconds)</label>
          <input
            type="number"
            value={customerData.duration || ''}
            onChange={(e) => handleInputChange('duration', parseInt(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            min="0"
            max="5000"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Campaign Contacts</label>
          <input
            type="number"
            value={customerData.campaign || ''}
            onChange={(e) => handleInputChange('campaign', parseInt(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            min="1"
            max="20"
          />
        </div>
      </div>

      <div className="text-center mb-6">
        <button
          onClick={makePrediction}
          className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-teal-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-teal-700 transform hover:scale-105 transition-all"
        >
          <TrendingUp className="w-5 h-5 mr-2" />
          Make Prediction
        </button>
      </div>

      {prediction && (
        <div className={`p-6 rounded-xl ${
          prediction.prediction === 'Will Purchase' 
            ? 'bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200' 
            : 'bg-gradient-to-r from-red-50 to-pink-50 border border-red-200'
        }`}>
          <div className="flex items-center mb-4">
            {prediction.prediction === 'Will Purchase' ? (
              <CheckCircle className="w-8 h-8 text-green-600 mr-3" />
            ) : (
              <AlertTriangle className="w-8 h-8 text-red-600 mr-3" />
            )}
            <div>
              <h4 className={`text-xl font-bold ${
                prediction.prediction === 'Will Purchase' ? 'text-green-800' : 'text-red-800'
              }`}>
                {prediction.prediction}
              </h4>
              <p className={`text-sm ${
                prediction.prediction === 'Will Purchase' ? 'text-green-600' : 'text-red-600'
              }`}>
                Confidence: {(prediction.confidence * 100).toFixed(1)}%
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-gray-700">Probability</p>
              <p className={`text-2xl font-bold ${
                prediction.prediction === 'Will Purchase' ? 'text-green-600' : 'text-red-600'
              }`}>
                {(prediction.probability * 100).toFixed(1)}%
              </p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-700">Recommendation</p>
              <p className={`text-sm ${
                prediction.prediction === 'Will Purchase' ? 'text-green-600' : 'text-red-600'
              }`}>
                {prediction.prediction === 'Will Purchase' 
                  ? 'High priority lead - follow up!' 
                  : 'Low conversion probability'
                }
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};