import React, { useState } from 'react';
import { sampleDataset } from '../data/sampleData';
import { CustomerData } from '../types';
import { BarChart3, PieChart, TrendingUp } from 'lucide-react';

interface DataExplorerProps {
  data: CustomerData[];
}

export const DataExplorer: React.FC<DataExplorerProps> = ({ data }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'demographics' | 'behavior'>('overview');

  const calculateStats = () => {
    const totalSamples = data.length;
    const positiveClass = data.filter(d => d.y === 'yes').length;
    const negativeClass = totalSamples - positiveClass;
    const avgAge = data.reduce((sum, d) => sum + d.age, 0) / totalSamples;
    const avgDuration = data.reduce((sum, d) => sum + d.duration, 0) / totalSamples;

    return {
      totalSamples,
      positiveClass,
      negativeClass,
      conversionRate: (positiveClass / totalSamples * 100).toFixed(1),
      avgAge: avgAge.toFixed(1),
      avgDuration: avgDuration.toFixed(0)
    };
  };

  const getJobDistribution = () => {
    const jobCounts: Record<string, number> = {};
    data.forEach(d => {
      jobCounts[d.job] = (jobCounts[d.job] || 0) + 1;
    });
    return Object.entries(jobCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 6);
  };

  const getMaritalDistribution = () => {
    const maritalCounts: Record<string, number> = {};
    data.forEach(d => {
      maritalCounts[d.marital] = (maritalCounts[d.marital] || 0) + 1;
    });
    return Object.entries(maritalCounts);
  };

  const stats = calculateStats();
  const jobDist = getJobDistribution();
  const maritalDist = getMaritalDistribution();

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center mb-6">
        <BarChart3 className="w-6 h-6 text-blue-600 mr-3" />
        <h3 className="text-xl font-bold text-gray-800">Dataset Explorer</h3>
      </div>

      <div className="flex space-x-4 mb-6 border-b">
        {[
          { key: 'overview', label: 'Overview', icon: TrendingUp },
          { key: 'demographics', label: 'Demographics', icon: PieChart },
          { key: 'behavior', label: 'Behavior', icon: BarChart3 }
        ].map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key as any)}
            className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
              activeTab === key
                ? 'bg-blue-100 text-blue-700 border-b-2 border-blue-600'
                : 'text-gray-600 hover:text-blue-600'
            }`}
          >
            <Icon className="w-4 h-4 mr-2" />
            {label}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-4 rounded-lg">
            <h4 className="font-semibold text-blue-800 mb-2">Dataset Size</h4>
            <p className="text-2xl font-bold text-blue-600">{stats.totalSamples}</p>
            <p className="text-sm text-blue-600">Total samples</p>
          </div>

          <div className="bg-gradient-to-r from-green-50 to-green-100 p-4 rounded-lg">
            <h4 className="font-semibold text-green-800 mb-2">Conversion Rate</h4>
            <p className="text-2xl font-bold text-green-600">{stats.conversionRate}%</p>
            <p className="text-sm text-green-600">{stats.positiveClass} conversions</p>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-4 rounded-lg">
            <h4 className="font-semibold text-purple-800 mb-2">Average Age</h4>
            <p className="text-2xl font-bold text-purple-600">{stats.avgAge}</p>
            <p className="text-sm text-purple-600">years old</p>
          </div>

          <div className="md:col-span-3 bg-gray-50 p-4 rounded-lg">
            <h4 className="font-semibold text-gray-800 mb-3">Class Distribution</h4>
            <div className="flex items-center space-x-6">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-red-500 rounded mr-2"></div>
                <span className="text-sm">No Purchase: {stats.negativeClass}</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-green-500 rounded mr-2"></div>
                <span className="text-sm">Purchase: {stats.positiveClass}</span>
              </div>
            </div>
            <div className="mt-3 bg-gray-200 rounded-full h-3">
              <div 
                className="bg-gradient-to-r from-green-400 to-green-600 h-3 rounded-full transition-all duration-1000"
                style={{ width: `${stats.conversionRate}%` }}
              ></div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'demographics' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold text-gray-800 mb-3">Job Distribution (Top 6)</h4>
            <div className="space-y-2">
              {jobDist.map(([job, count]) => (
                <div key={job} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm font-medium capitalize">{job}</span>
                  <span className="text-sm text-gray-600">{count}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-gray-800 mb-3">Marital Status</h4>
            <div className="space-y-2">
              {maritalDist.map(([status, count]) => (
                <div key={status} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm font-medium capitalize">{status}</span>
                  <span className="text-sm text-gray-600">{count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'behavior' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-semibold text-gray-800 mb-3">Call Duration</h4>
            <p className="text-lg font-bold text-blue-600">{stats.avgDuration} seconds</p>
            <p className="text-sm text-gray-600">Average call duration</p>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-semibold text-gray-800 mb-3">Contact Method</h4>
            <div className="space-y-2">
              {['cellular', 'telephone'].map(method => {
                const count = data.filter(d => d.contact === method).length;
                return (
                  <div key={method} className="flex items-center justify-between">
                    <span className="text-sm font-medium capitalize">{method}</span>
                    <span className="text-sm text-gray-600">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};