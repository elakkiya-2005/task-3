import React, { useState, useEffect } from 'react';
import { DecisionTreeClassifier } from '../algorithms/DecisionTree';
import { DataPreprocessor } from '../utils/dataPreprocessing';
import { ModelMetrics, ProcessedData } from '../types';
import { Play, CheckCircle, AlertCircle, Settings, Brain } from 'lucide-react';

interface ModelTrainingProps {
  data: ProcessedData[];
  onModelTrained: (model: DecisionTreeClassifier, metrics: ModelMetrics) => void;
}

export const ModelTraining: React.FC<ModelTrainingProps> = ({ data, onModelTrained }) => {
  const [isTraining, setIsTraining] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [metrics, setMetrics] = useState<ModelMetrics | null>(null);
  const [hyperparams, setHyperparams] = useState({
    maxDepth: 10,
    minSamplesSplit: 2,
    minSamplesLeaf: 1
  });

  const trainModel = async () => {
    setIsTraining(true);
    setIsCompleted(false);

    try {
      // Simulate training delay for better UX
      await new Promise(resolve => setTimeout(resolve, 2000));

      const preprocessor = new DataPreprocessor();
      const { trainData, testData } = preprocessor.splitData(data, 0.2);

      const model = new DecisionTreeClassifier(
        hyperparams.maxDepth,
        hyperparams.minSamplesSplit,
        hyperparams.minSamplesLeaf
      );

      model.train(trainData);
      const modelMetrics = model.evaluate(testData);

      setMetrics(modelMetrics);
      setIsCompleted(true);
      onModelTrained(model, modelMetrics);
    } catch (error) {
      console.error('Training failed:', error);
    } finally {
      setIsTraining(false);
    }
  };

  const formatMetric = (value: number): string => {
    return (value * 100).toFixed(1) + '%';
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center mb-6">
        <Brain className="w-6 h-6 text-indigo-600 mr-3" />
        <h3 className="text-xl font-bold text-gray-800">Model Training</h3>
      </div>

      {/* Hyperparameters */}
      <div className="mb-6 p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center mb-3">
          <Settings className="w-5 h-5 text-gray-600 mr-2" />
          <h4 className="font-semibold text-gray-800">Hyperparameters</h4>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Max Depth
            </label>
            <input
              type="number"
              value={hyperparams.maxDepth}
              onChange={(e) => setHyperparams(prev => ({ ...prev, maxDepth: parseInt(e.target.value) }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              min="1"
              max="20"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Min Samples Split
            </label>
            <input
              type="number"
              value={hyperparams.minSamplesSplit}
              onChange={(e) => setHyperparams(prev => ({ ...prev, minSamplesSplit: parseInt(e.target.value) }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              min="2"
              max="10"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Min Samples Leaf
            </label>
            <input
              type="number"
              value={hyperparams.minSamplesLeaf}
              onChange={(e) => setHyperparams(prev => ({ ...prev, minSamplesLeaf: parseInt(e.target.value) }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              min="1"
              max="5"
            />
          </div>
        </div>
      </div>

      {/* Training Button */}
      <div className="text-center mb-6">
        <button
          onClick={trainModel}
          disabled={isTraining || data.length === 0}
          className={`inline-flex items-center px-6 py-3 rounded-lg font-semibold transition-all ${
            isTraining
              ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
              : 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700 transform hover:scale-105'
          }`}
        >
          {isTraining ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
              Training Model...
            </>
          ) : (
            <>
              <Play className="w-5 h-5 mr-2" />
              Train Decision Tree
            </>
          )}
        </button>
      </div>

      {/* Training Progress */}
      {isTraining && (
        <div className="mb-6">
          <div className="bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-indigo-400 to-purple-400 h-2 rounded-full animate-pulse"></div>
          </div>
          <p className="text-center text-sm text-gray-600 mt-2">
            Building decision tree and evaluating performance...
          </p>
        </div>
      )}

      {/* Results */}
      {isCompleted && metrics && (
        <div className="space-y-4">
          <div className="flex items-center text-green-600 mb-4">
            <CheckCircle className="w-5 h-5 mr-2" />
            <span className="font-semibold">Model training completed successfully!</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-4 rounded-lg">
              <h4 className="font-semibold text-blue-800 mb-1">Accuracy</h4>
              <p className="text-2xl font-bold text-blue-600">{formatMetric(metrics.accuracy)}</p>
            </div>

            <div className="bg-gradient-to-r from-green-50 to-green-100 p-4 rounded-lg">
              <h4 className="font-semibold text-green-800 mb-1">Precision</h4>
              <p className="text-2xl font-bold text-green-600">{formatMetric(metrics.precision)}</p>
            </div>

            <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-4 rounded-lg">
              <h4 className="font-semibold text-purple-800 mb-1">Recall</h4>
              <p className="text-2xl font-bold text-purple-600">{formatMetric(metrics.recall)}</p>
            </div>

            <div className="bg-gradient-to-r from-orange-50 to-orange-100 p-4 rounded-lg">
              <h4 className="font-semibold text-orange-800 mb-1">F1-Score</h4>
              <p className="text-2xl font-bold text-orange-600">{formatMetric(metrics.f1Score)}</p>
            </div>
          </div>

          {/* Confusion Matrix */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-semibold text-gray-800 mb-3">Confusion Matrix</h4>
            <div className="grid grid-cols-2 gap-2 max-w-xs">
              <div className="bg-red-100 p-3 rounded text-center">
                <div className="text-sm font-medium text-red-800">True Negative</div>
                <div className="text-xl font-bold text-red-600">{metrics.confusionMatrix[0][0]}</div>
              </div>
              <div className="bg-orange-100 p-3 rounded text-center">
                <div className="text-sm font-medium text-orange-800">False Positive</div>
                <div className="text-xl font-bold text-orange-600">{metrics.confusionMatrix[0][1]}</div>
              </div>
              <div className="bg-yellow-100 p-3 rounded text-center">
                <div className="text-sm font-medium text-yellow-800">False Negative</div>
                <div className="text-xl font-bold text-yellow-600">{metrics.confusionMatrix[1][0]}</div>
              </div>
              <div className="bg-green-100 p-3 rounded text-center">
                <div className="text-sm font-medium text-green-800">True Positive</div>
                <div className="text-xl font-bold text-green-600">{metrics.confusionMatrix[1][1]}</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};