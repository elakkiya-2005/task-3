export interface CustomerData {
  age: number;
  job: string;
  marital: string;
  education: string;
  default: string;
  housing: string;
  loan: string;
  contact: string;
  month: string;
  day_of_week: string;
  duration: number;
  campaign: number;
  pdays: number;
  previous: number;
  poutcome: string;
  emp_var_rate: number;
  cons_price_idx: number;
  cons_conf_idx: number;
  euribor3m: number;
  nr_employed: number;
  y: string; // target variable
}

export interface ProcessedData {
  features: number[];
  target: number;
  featureNames: string[];
}

export interface DecisionNode {
  feature?: number;
  threshold?: number;
  left?: DecisionNode;
  right?: DecisionNode;
  prediction?: number;
  samples?: number;
  gini?: number;
  isLeaf: boolean;
}

export interface ModelMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  confusionMatrix: number[][];
}

export interface PredictionResult {
  prediction: string;
  probability: number;
  confidence: number;
}