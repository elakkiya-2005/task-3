import { CustomerData, ProcessedData } from '../types';
import { 
  jobCategories, maritalCategories, educationCategories, 
  monthCategories, dayCategories, contactCategories, 
  poutcomeCategories, binaryCategories 
} from '../data/sampleData';

export class DataPreprocessor {
  private jobEncoder: Map<string, number> = new Map();
  private maritalEncoder: Map<string, number> = new Map();
  private educationEncoder: Map<string, number> = new Map();
  private monthEncoder: Map<string, number> = new Map();
  private dayEncoder: Map<string, number> = new Map();
  private contactEncoder: Map<string, number> = new Map();
  private poutcomeEncoder: Map<string, number> = new Map();
  private binaryEncoder: Map<string, number> = new Map();

  constructor() {
    this.initializeEncoders();
  }

  private initializeEncoders(): void {
    jobCategories.forEach((job, index) => this.jobEncoder.set(job, index));
    maritalCategories.forEach((status, index) => this.maritalEncoder.set(status, index));
    educationCategories.forEach((edu, index) => this.educationEncoder.set(edu, index));
    monthCategories.forEach((month, index) => this.monthEncoder.set(month, index));
    dayCategories.forEach((day, index) => this.dayEncoder.set(day, index));
    contactCategories.forEach((contact, index) => this.contactEncoder.set(contact, index));
    poutcomeCategories.forEach((outcome, index) => this.poutcomeEncoder.set(outcome, index));
    binaryCategories.forEach((binary, index) => this.binaryEncoder.set(binary, index));
  }

  public preprocessDataset(dataset: CustomerData[]): ProcessedData[] {
    return dataset.map(customer => this.preprocessSingle(customer));
  }

  public preprocessSingle(customer: CustomerData): ProcessedData {
    const features = [
      customer.age,
      this.jobEncoder.get(customer.job) || 0,
      this.maritalEncoder.get(customer.marital) || 0,
      this.educationEncoder.get(customer.education) || 0,
      this.binaryEncoder.get(customer.default) || 0,
      this.binaryEncoder.get(customer.housing) || 0,
      this.binaryEncoder.get(customer.loan) || 0,
      this.contactEncoder.get(customer.contact) || 0,
      this.monthEncoder.get(customer.month) || 0,
      this.dayEncoder.get(customer.day_of_week) || 0,
      customer.duration,
      customer.campaign,
      customer.pdays,
      customer.previous,
      this.poutcomeEncoder.get(customer.poutcome) || 0,
      customer.emp_var_rate,
      customer.cons_price_idx,
      customer.cons_conf_idx,
      customer.euribor3m,
      customer.nr_employed
    ];

    const target = customer.y === 'yes' ? 1 : 0;

    const featureNames = [
      'age', 'job', 'marital', 'education', 'default', 'housing', 'loan',
      'contact', 'month', 'day_of_week', 'duration', 'campaign', 'pdays',
      'previous', 'poutcome', 'emp_var_rate', 'cons_price_idx', 'cons_conf_idx',
      'euribor3m', 'nr_employed'
    ];

    return { features, target, featureNames };
  }

  public normalizeFeatures(data: ProcessedData[]): ProcessedData[] {
    const numFeatures = data[0].features.length;
    const means = new Array(numFeatures).fill(0);
    const stds = new Array(numFeatures).fill(0);

    // Calculate means
    for (let i = 0; i < numFeatures; i++) {
      means[i] = data.reduce((sum, row) => sum + row.features[i], 0) / data.length;
    }

    // Calculate standard deviations
    for (let i = 0; i < numFeatures; i++) {
      const variance = data.reduce((sum, row) => 
        sum + Math.pow(row.features[i] - means[i], 2), 0) / data.length;
      stds[i] = Math.sqrt(variance);
    }

    // Normalize data
    return data.map(row => ({
      ...row,
      features: row.features.map((feature, i) => 
        stds[i] === 0 ? 0 : (feature - means[i]) / stds[i]
      )
    }));
  }

  public splitData(data: ProcessedData[], testSize: number = 0.2): {
    trainData: ProcessedData[];
    testData: ProcessedData[];
  } {
    const shuffled = [...data].sort(() => Math.random() - 0.5);
    const splitIndex = Math.floor(data.length * (1 - testSize));
    
    return {
      trainData: shuffled.slice(0, splitIndex),
      testData: shuffled.slice(splitIndex)
    };
  }
}