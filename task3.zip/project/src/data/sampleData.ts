import { CustomerData } from '../types';

export const sampleDataset: CustomerData[] = [
  {
    age: 56, job: "housemaid", marital: "married", education: "basic.4y",
    default: "no", housing: "no", loan: "no", contact: "telephone",
    month: "may", day_of_week: "mon", duration: 261, campaign: 1,
    pdays: 999, previous: 0, poutcome: "nonexistent",
    emp_var_rate: 1.1, cons_price_idx: 93.994, cons_conf_idx: -36.4,
    euribor3m: 4.857, nr_employed: 5191.0, y: "no"
  },
  {
    age: 57, job: "services", marital: "married", education: "high.school",
    default: "unknown", housing: "no", loan: "no", contact: "telephone",
    month: "may", day_of_week: "mon", duration: 149, campaign: 1,
    pdays: 999, previous: 0, poutcome: "nonexistent",
    emp_var_rate: 1.1, cons_price_idx: 93.994, cons_conf_idx: -36.4,
    euribor3m: 4.857, nr_employed: 5191.0, y: "no"
  },
  {
    age: 37, job: "services", marital: "married", education: "high.school",
    default: "no", housing: "yes", loan: "no", contact: "telephone",
    month: "may", day_of_week: "mon", duration: 226, campaign: 1,
    pdays: 999, previous: 0, poutcome: "nonexistent",
    emp_var_rate: 1.1, cons_price_idx: 93.994, cons_conf_idx: -36.4,
    euribor3m: 4.857, nr_employed: 5191.0, y: "no"
  },
  {
    age: 40, job: "admin.", marital: "married", education: "basic.6y",
    default: "no", housing: "no", loan: "no", contact: "telephone",
    month: "may", day_of_week: "mon", duration: 151, campaign: 1,
    pdays: 999, previous: 0, poutcome: "nonexistent",
    emp_var_rate: 1.1, cons_price_idx: 93.994, cons_conf_idx: -36.4,
    euribor3m: 4.857, nr_employed: 5191.0, y: "no"
  },
  {
    age: 56, job: "services", marital: "married", education: "high.school",
    default: "no", housing: "no", loan: "yes", contact: "telephone",
    month: "may", day_of_week: "mon", duration: 307, campaign: 1,
    pdays: 999, previous: 0, poutcome: "nonexistent",
    emp_var_rate: 1.1, cons_price_idx: 93.994, cons_conf_idx: -36.4,
    euribor3m: 4.857, nr_employed: 5191.0, y: "no"
  },
  {
    age: 45, job: "services", marital: "married", education: "basic.9y",
    default: "unknown", housing: "no", loan: "no", contact: "telephone",
    month: "may", day_of_week: "mon", duration: 198, campaign: 1,
    pdays: 999, previous: 0, poutcome: "nonexistent",
    emp_var_rate: 1.1, cons_price_idx: 93.994, cons_conf_idx: -36.4,
    euribor3m: 4.857, nr_employed: 5191.0, y: "no"
  },
  {
    age: 59, job: "admin.", marital: "married", education: "professional.course",
    default: "no", housing: "no", loan: "no", contact: "telephone",
    month: "may", day_of_week: "mon", duration: 139, campaign: 1,
    pdays: 999, previous: 0, poutcome: "nonexistent",
    emp_var_rate: 1.1, cons_price_idx: 93.994, cons_conf_idx: -36.4,
    euribor3m: 4.857, nr_employed: 5191.0, y: "no"
  },
  {
    age: 41, job: "blue-collar", marital: "married", education: "unknown",
    default: "unknown", housing: "no", loan: "no", contact: "telephone",
    month: "may", day_of_week: "mon", duration: 217, campaign: 1,
    pdays: 999, previous: 0, poutcome: "nonexistent",
    emp_var_rate: 1.1, cons_price_idx: 93.994, cons_conf_idx: -36.4,
    euribor3m: 4.857, nr_employed: 5191.0, y: "no"
  },
  {
    age: 24, job: "technician", marital: "single", education: "professional.course",
    default: "no", housing: "yes", loan: "no", contact: "cellular",
    month: "aug", day_of_week: "wed", duration: 380, campaign: 1,
    pdays: 999, previous: 0, poutcome: "nonexistent",
    emp_var_rate: 1.4, cons_price_idx: 93.444, cons_conf_idx: -36.1,
    euribor3m: 4.963, nr_employed: 5228.1, y: "yes"
  },
  {
    age: 25, job: "services", marital: "single", education: "high.school",
    default: "no", housing: "yes", loan: "no", contact: "cellular",
    month: "aug", day_of_week: "wed", duration: 601, campaign: 1,
    pdays: 999, previous: 0, poutcome: "nonexistent",
    emp_var_rate: 1.4, cons_price_idx: 93.444, cons_conf_idx: -36.1,
    euribor3m: 4.963, nr_employed: 5228.1, y: "yes"
  }
];

export const jobCategories = [
  "admin.", "blue-collar", "entrepreneur", "housemaid", "management",
  "retired", "self-employed", "services", "student", "technician", "unemployed", "unknown"
];

export const maritalCategories = ["divorced", "married", "single", "unknown"];

export const educationCategories = [
  "basic.4y", "basic.6y", "basic.9y", "high.school", "illiterate",
  "professional.course", "university.degree", "unknown"
];

export const monthCategories = [
  "jan", "feb", "mar", "apr", "may", "jun",
  "jul", "aug", "sep", "oct", "nov", "dec"
];

export const dayCategories = ["mon", "tue", "wed", "thu", "fri"];

export const contactCategories = ["cellular", "telephone"];

export const poutcomeCategories = ["failure", "nonexistent", "success"];

export const binaryCategories = ["no", "yes", "unknown"];